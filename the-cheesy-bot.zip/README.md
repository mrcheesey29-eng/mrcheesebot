# The Cheesy Bot 🍕 — Discord moderation + helpful assistant

## What changed for your choices

- Bot identity/activity: **The Cheesy Bot**.
- Helper works with both `/help question:...` and direct mentions like `@The Cheesy Bot how do I build a PC?`.
- Progressive moderation policy for AI-detected harassment and hate:
  1. First recorded incident: warning.
  2. Second recorded incident: 10-minute timeout.
  3. Third recorded incident: 60-minute timeout.
  4. Fourth and later incidents: ban.
- Includes a Dockerfile and `render.yaml` to help deploy as an always-on cloud worker.

## Before you deploy

Automatic moderation can make mistakes, including with quoted or educational discussion of hateful language. Test in a private server first, keep a moderator log, and provide a way to appeal. The bot only acts when the moderation API is configured and a score crosses a threshold. The incident counter currently counts all recorded moderation infractions for that member in that server.

## 1. Create the Discord bot

1. Open https://discord.com/developers/applications and create an application named **The Cheesy Bot**.
2. Open **Bot** and create/reset its token. Keep the token secret.
3. Enable **Message Content Intent** and **Server Members Intent**.
4. Under **OAuth2 → URL Generator**, select `bot` and `applications.commands`.
5. Grant the permissions it needs: View Channels, Send Messages, Read Message History, Manage Messages, Moderate Members, and Ban Members. Invite it to your server.
6. Move its role above regular members, but below trusted staff roles.

## 2. Create API credentials

- Create an OpenAI API key from your OpenAI developer account. API usage may be billed separately from a ChatGPT subscription.
- Do not paste either secret into public chat, source code, or a public repository.

## 3. Deploy on Render as a background worker

1. Put this project in a private GitHub repository.
2. In Render, create a **Background Worker** from that repository. The included `render.yaml` uses Docker.
3. Add environment variables in Render's dashboard:
   - `DISCORD_TOKEN`
   - `OPENAI_API_KEY`
   - `GUILD_ID` (recommended during setup; use your test server ID)
   - `MOD_LOG_CHANNEL_ID` (optional but recommended)
   - `MODERATOR_ROLE_ID` (optional)
4. Deploy and inspect the worker logs. It should report that The Cheesy Bot is online.
5. Once tested, you can clear `GUILD_ID` and redeploy if you want global slash-command registration. Global commands can take time to propagate.

Check the hosting provider's current pricing and worker limits before choosing a plan; a continuously running worker may require a paid plan.

## 4. Local test (optional)

Install Node.js 20+, copy `.env.example` to `.env`, fill in secrets, then run:

```bash
npm install
npm start
```

## Commands

- `/help question:<question>` — ask the helper.
- Mention the bot and ask a question — also invokes the helper.
- `/report details:<what happened>` — report behavior.
- `/warn member:<member> reason:<reason>`
- `/timeout member:<member> minutes:<1–40320> reason:<reason>`
- `/ban member:<member> reason:<reason>`
- `/infractions member:<member>`
- `/clearinfractions member:<member>`

## Data and privacy

Infractions are stored in `data/infractions.json` in the running container. Ephemeral container files may not survive redeploys, so use a persistent disk or database if you need durable moderation history. Message content sent to the moderation API and questions sent to the helper API are processed by the API provider; disclose this in your server rules/privacy notice.
