require("dotenv").config();

const fs = require("node:fs");
const path = require("node:path");
const {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  REST,
  Routes,
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType
} = require("discord.js");
const OpenAI = require("openai");

const TOKEN = process.env.DISCORD_TOKEN;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const GUILD_ID = process.env.GUILD_ID || "";
const MOD_LOG_CHANNEL_ID = process.env.MOD_LOG_CHANNEL_ID || "";
const MODERATOR_ROLE_ID = process.env.MODERATOR_ROLE_ID || "";
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";
const HARASSMENT_THRESHOLD = Number(process.env.HARASSMENT_TIMEOUT_THRESHOLD || 0.82);
const HATE_BAN_THRESHOLD = Number(process.env.HATE_BAN_THRESHOLD || 0.93);
const REPEAT_OFFENSES = Number(process.env.REPEAT_OFFENSES_BEFORE_TIMEOUT || 3);
const TIMEOUT_MINUTES = Number(process.env.TIMEOUT_MINUTES || 30);

if (!TOKEN) {
  console.error("Missing DISCORD_TOKEN. Copy .env.example to .env and add your bot token.");
  process.exit(1);
}

const openai = OPENAI_API_KEY ? new OpenAI({ apiKey: OPENAI_API_KEY }) : null;
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
  partials: [Partials.Channel]
});

const DATA_DIR = path.join(__dirname, "..", "data");
const DATA_FILE = path.join(DATA_DIR, "infractions.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({}, null, 2));

function loadData() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, "utf8")); }
  catch { return {}; }
}
function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}
let infractions = loadData();

function userKey(guildId, userId) { return `${guildId}:${userId}`; }
function addInfraction(guildId, userId, item) {
  const key = userKey(guildId, userId);
  infractions[key] ||= [];
  infractions[key].push({ ...item, at: new Date().toISOString() });
  // Keep the latest 100 records per user.
  infractions[key] = infractions[key].slice(-100);
  saveData(infractions);
  return infractions[key].length;
}
function clearInfractions(guildId, userId) {
  delete infractions[userKey(guildId, userId)];
  saveData(infractions);
}
function getInfractions(guildId, userId) {
  return infractions[userKey(guildId, userId)] || [];
}
function isModerator(member) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator) ||
      member.permissions.has(PermissionFlagsBits.ModerateMembers) ||
      member.permissions.has(PermissionFlagsBits.BanMembers)) return true;
  return Boolean(MODERATOR_ROLE_ID && member.roles?.cache?.has(MODERATOR_ROLE_ID));
}

async function logAction(guild, text) {
  if (!MOD_LOG_CHANNEL_ID) return;
  const channel = guild.channels.cache.get(MOD_LOG_CHANNEL_ID);
  if (channel && channel.isTextBased()) {
    try { await channel.send({ content: text }); } catch (e) {
      console.warn("Could not post to mod log channel:", e.message);
    }
  }
}

async function classifyMessage(text) {
  if (!openai) return { available: false };
  try {
    const result = await openai.moderations.create({
      model: "omni-moderation-latest",
      input: text.slice(0, 8000)
    });
    const item = result.results?.[0];
    if (!item) return { available: false };
    const s = item.category_scores || {};
    return {
      available: true,
      flagged: Boolean(item.flagged),
      harassment: Number(s.harassment || 0),
      harassmentThreatening: Number(s["harassment/threatening"] || 0),
      hate: Number(s.hate || 0),
      hateThreatening: Number(s["hate/threatening"] || 0)
    };
  } catch (error) {
    console.error("Moderation API error:", error.message);
    return { available: false };
  }
}

async function timeoutMember(message, minutes, reason) {
  try {
    await message.member.timeout(minutes * 60 * 1000, reason);
    await logAction(message.guild,
      `⏳ Timed out ${message.author.tag} (${message.author.id}) for ${minutes} minutes. Reason: ${reason}`);
    return true;
  } catch (error) {
    console.error("Timeout failed:", error.message);
    await logAction(message.guild, `⚠️ Could not timeout ${message.author.tag}: ${error.message}`);
    return false;
  }
}

async function banMember(message, reason) {
  try {
    await message.guild.members.ban(message.author.id, {
      reason: `The Cheesy Bot automatic moderation: ${reason}`
    });
    await logAction(message.guild,
      `🔨 Banned ${message.author.tag} (${message.author.id}). Reason: ${reason}`);
    return true;
  } catch (error) {
    console.error("Ban failed:", error.message);
    await logAction(message.guild, `⚠️ Could not ban ${message.author.tag}: ${error.message}`);
    return false;
  }
}

const commands = [
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("Ask the helper bot a question")
    .addStringOption(o => o.setName("question").setDescription("What do you need help with?").setRequired(true).setMaxLength(1500)),
  new SlashCommandBuilder()
    .setName("report")
    .setDescription("Report a message or behavior to moderators")
    .addStringOption(o => o.setName("details").setDescription("Explain what happened; include message links if possible").setRequired(true).setMaxLength(1500)),
  new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName("member").setDescription("Member to warn").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason for warning").setRequired(true).setMaxLength(500)),
  new SlashCommandBuilder()
    .setName("timeout")
    .setDescription("Timeout a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName("member").setDescription("Member to timeout").setRequired(true))
    .addIntegerOption(o => o.setName("minutes").setDescription("Duration in minutes (1-40320)").setMinValue(1).setMaxValue(40320).setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true).setMaxLength(500)),
  new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban a member")
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(o => o.setName("member").setDescription("Member to ban").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true).setMaxLength(500)),
  new SlashCommandBuilder()
    .setName("infractions")
    .setDescription("View a member's recorded moderation actions")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName("member").setDescription("Member to check").setRequired(true)),
  new SlashCommandBuilder()
    .setName("clearinfractions")
    .setDescription("Clear a member's recorded moderation actions")
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption(o => o.setName("member").setDescription("Member to clear").setRequired(true))
].map(c => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  if (GUILD_ID) {
    await rest.put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), { body: commands });
    console.log(`Registered commands for test server ${GUILD_ID}.`);
  } else {
    await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
    console.log("Registered global commands (may take a while to appear).");
  }
}

client.once(Events.ClientReady, async readyClient => {
  console.log(`The Cheesy Bot is online as ${readyClient.user.tag}`);
  readyClient.user.setActivity("helping the server 🍕");
  try { await registerCommands(); }
  catch (error) { console.error("Command registration failed:", error.message); }
});

async function answerHelper(question) {
  if (!openai) return "My AI helper isn't configured yet. The server owner needs to add OPENAI_API_KEY to the bot's environment variables.";
  try {
    const answer = await openai.responses.create({
      model: MODEL,
      instructions: "You are The Cheesy Bot, a kind, patient Discord helper. Give clear, practical step-by-step answers. Ask a brief follow-up if essential information is missing. Encourage safe, legal, respectful behavior. If someone seems distressed or in danger, respond with empathy and encourage contacting a trusted person or appropriate local emergency support. Do not claim to have performed real-world actions.",
      input: question,
      max_output_tokens: 700
    });
    return (answer.output_text || "Sorry, I couldn't create an answer. Please try again.").slice(0, 1900);
  } catch (error) {
    console.error("Helper AI error:", error.message);
    return "Sorry, my helper service is having trouble right now. Please try again later.";
  }
}

client.on(Events.MessageCreate, async message => {
  if (!message.guild || message.author.bot || !message.member) return;
  const content = message.content.trim();
  if (!content) return;

  // Do not auto-moderate moderators or admins.
  if (isModerator(message.member)) return;

  // Mention-based helper: reply when a member mentions The Cheesy Bot.
  // Remove the bot mention from the question and ignore empty mentions.
  if (client.user && message.mentions.users.has(client.user.id)) {
    const question = content
      .replace(new RegExp(`<@!?${client.user.id}>`, "g"), "")
      .trim();
    if (question.length > 0) {
      const reply = await answerHelper(question);
      await message.reply({ content: reply, allowedMentions: { repliedUser: false } }).catch(() => {});
    } else {
      await message.reply({
        content: "Hey! 🍕 Mention me with a question, or use `/help`.",
        allowedMentions: { repliedUser: false }
      }).catch(() => {});
    }
  }

  // AI moderation requires an OpenAI API key. If unavailable, do not pretend
  // that messages were checked.
  const result = await classifyMessage(content);
  if (!result.available) return;

  const hateScore = Math.max(result.hate, result.hateThreatening);
  const harassmentScore = Math.max(result.harassment, result.harassmentThreatening);
  const isHate = hateScore >= HATE_BAN_THRESHOLD;
  const isHarassment = harassmentScore >= HARASSMENT_THRESHOLD;

  // Only act when one of the configured categories crosses its threshold.
  // Hate and harassment both use the user's requested progressive policy:
  // warning first, timeout on repeated incidents, ban after repeated offenses.
  if (!isHate && !isHarassment) return;

  try { await message.delete(); } catch {}
  const category = isHate ? "possible hate speech" : "possible harassment";
  const score = isHate ? hateScore : harassmentScore;
  const count = addInfraction(message.guild.id, message.author.id, {
    type: isHate ? "hate-speech" : "harassment",
    score,
    message: content.slice(0, 300),
    moderator: "The Cheesy Bot auto-moderation"
  });

  let actionText = "";
  if (count === 1) {
    actionText = "This is your first recorded incident, so you have been warned. Please treat everyone respectfully.";
  } else if (count === 2) {
    const ok = await timeoutMember(message, 10, `repeat ${category} (incident ${count})`);
    actionText = ok
      ? "You have been timed out for 10 minutes because of repeated violations."
      : "This is a repeat violation. A moderator needs to review it because I couldn't apply the timeout.";
  } else if (count === 3) {
    const ok = await timeoutMember(message, 60, `repeated ${category} (incident ${count})`);
    actionText = ok
      ? "You have been timed out for 60 minutes because of repeated violations."
      : "This is a further repeat violation. A moderator needs to review it because I couldn't apply the timeout.";
  } else {
    const ok = await banMember(message, `repeated ${category} (incident ${count})`);
    actionText = ok
      ? "You have been banned because of repeated violations. If you believe this was a mistake, contact the server staff through their appeal process."
      : "This is a serious repeat violation. A moderator needs to review it because I couldn't apply the ban.";
  }

  await message.channel.send({
    content: `⚠️ ${message.author}, your message was removed because it may be ${category}. ${actionText}`,
    allowedMentions: { users: [message.author.id] }
  }).catch(() => {});
  await logAction(message.guild,
    `⚠️ The Cheesy Bot removed a message by ${message.author.tag} (${message.author.id}); category: ${category}; score: ${score.toFixed(2)}; recorded incident: ${count}.`);
});

client.on(Events.InteractionCreate, async interaction => {
  if (interaction.isChatInputCommand()) {
    const { commandName } = interaction;

    if (commandName === "help") {
      await interaction.deferReply();
      const question = interaction.options.getString("question", true);
      const reply = await answerHelper(question);
      return interaction.editReply(reply);
    }

    if (commandName === "report") {
      const details = interaction.options.getString("details", true);
      await logAction(interaction.guild,
        `📣 **Member report** from ${interaction.user.tag} (${interaction.user.id}) in <#${interaction.channelId}>:\n${details}`);
      return interaction.reply({ content: "Thanks for reporting this. The moderators have been notified if a mod-log channel is configured.", ephemeral: true });
    }

    if (!isModerator(interaction.member)) {
      return interaction.reply({ content: "You need moderator permissions to use that command.", ephemeral: true });
    }

    if (commandName === "warn") {
      const user = interaction.options.getUser("member", true);
      const reason = interaction.options.getString("reason", true);
      const count = addInfraction(interaction.guildId, user.id, {
        type: "manual-warning", reason, moderator: interaction.user.tag
      });
      await logAction(interaction.guild, `⚠️ ${user.tag} was warned by ${interaction.user.tag}. Reason: ${reason}`);
      return interaction.reply({ content: `Warned ${user.tag}. Recorded infractions: ${count}.`, ephemeral: true });
    }

    if (commandName === "timeout") {
      const user = interaction.options.getUser("member", true);
      const minutes = interaction.options.getInteger("minutes", true);
      const reason = interaction.options.getString("reason", true);
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return interaction.reply({ content: "That member is not in this server.", ephemeral: true });
      try {
        await member.timeout(minutes * 60 * 1000, `${interaction.user.tag}: ${reason}`);
        addInfraction(interaction.guildId, user.id, { type: "manual-timeout", minutes, reason, moderator: interaction.user.tag });
        await logAction(interaction.guild, `⏳ ${user.tag} timed out for ${minutes} minutes by ${interaction.user.tag}. Reason: ${reason}`);
        return interaction.reply({ content: `Timed out ${user.tag} for ${minutes} minutes.`, ephemeral: true });
      } catch (error) {
        return interaction.reply({ content: `I couldn't timeout that member. Check my role position and permissions. (${error.message})`, ephemeral: true });
      }
    }

    if (commandName === "ban") {
      const user = interaction.options.getUser("member", true);
      const reason = interaction.options.getString("reason", true);
      try {
        await interaction.guild.members.ban(user.id, { reason: `${interaction.user.tag}: ${reason}` });
        addInfraction(interaction.guildId, user.id, { type: "manual-ban", reason, moderator: interaction.user.tag });
        await logAction(interaction.guild, `🔨 ${user.tag} banned by ${interaction.user.tag}. Reason: ${reason}`);
        return interaction.reply({ content: `Banned ${user.tag}.`, ephemeral: true });
      } catch (error) {
        return interaction.reply({ content: `I couldn't ban that member. Check my role position and permissions. (${error.message})`, ephemeral: true });
      }
    }

    if (commandName === "infractions") {
      const user = interaction.options.getUser("member", true);
      const items = getInfractions(interaction.guildId, user.id);
      const summary = items.slice(-10).map((x, i) => `${i + 1}. **${x.type}** — ${x.reason || x.message || "No details"} (${x.at || "unknown date"})`).join("\n");
      return interaction.reply({ content: `**Latest infractions for ${user.tag}**\n${summary || "No recorded infractions."}`.slice(0, 1900), ephemeral: true });
    }

    if (commandName === "clearinfractions") {
      const user = interaction.options.getUser("member", true);
      clearInfractions(interaction.guildId, user.id);
      await logAction(interaction.guild, `🧹 Infractions cleared for ${user.tag} by ${interaction.user.tag}.`);
      return interaction.reply({ content: `Cleared recorded infractions for ${user.tag}.`, ephemeral: true });
    }
  }
});

client.on(Events.Error, error => console.error("Discord client error:", error));
process.on("unhandledRejection", error => console.error("Unhandled rejection:", error));

client.login(TOKEN);
